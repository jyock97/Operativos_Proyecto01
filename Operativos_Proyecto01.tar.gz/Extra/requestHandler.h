#ifndef _REQUESTHANDLER_H
#define _REQUESTHANDLER_H 

char *accept_request(int socket, int port, char *currentPath);//Se discrimina el protocolo por el puerto y se le devuelve su respuesta

#endif